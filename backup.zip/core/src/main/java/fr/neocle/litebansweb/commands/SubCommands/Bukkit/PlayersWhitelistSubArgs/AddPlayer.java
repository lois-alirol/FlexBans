package fr.neocle.litebansweb.commands.SubCommands.Bukkit.PlayersWhitelistSubArgs;

import fr.neocle.litebansweb.api.LitebansWebAPI;
import fr.neocle.litebansweb.commands.Shared.PlayersWhitelistCommand;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.nio.file.Path;
import java.util.logging.Logger;

public class AddPlayer implements CommandExecutor {
    private final PlayersWhitelistCommand whitelistMethods;

    public AddPlayer(LitebansWebAPI api, Path dataFolder, Logger logger) {
        this.whitelistMethods = new PlayersWhitelistCommand(api, dataFolder.resolve("config.yml"), logger) {
            @Override
            protected void sendMessage(Object sender, String message) {
                if (sender instanceof CommandSender commandSender) {
                    commandSender.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
                }
            }
        };
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("litebansweb.players.add")) {
            sender.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
            return true;
        }

        if (args.length != 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /litebansweb players add <player>");
            return true;
        }

        String playerName = args[1];
        whitelistMethods.executeCommand(sender, playerName, true);
        return true;
    }
}
