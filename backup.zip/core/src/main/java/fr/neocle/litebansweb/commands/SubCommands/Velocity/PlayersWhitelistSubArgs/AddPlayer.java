package fr.neocle.litebansweb.commands.SubCommands.Velocity.PlayersWhitelistSubArgs;

import fr.neocle.litebansweb.api.LitebansWebAPI;
import fr.neocle.litebansweb.commands.Shared.PlayersWhitelistCommand;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;

import net.kyori.adventure.text.Component;
import java.nio.file.Path;
import java.util.logging.Logger;

public class AddPlayer extends PlayersWhitelistCommand implements SimpleCommand {
    
    public AddPlayer(LitebansWebAPI api, Path dataFolder, Logger logger) {
        super(api, dataFolder.resolve("config.yml"), logger);
    }

    @Override
    public void execute(Invocation invocation) {
        CommandSource source = invocation.source();
        String[] args = invocation.arguments();

        if (!source.hasPermission("litebansweb.players.add")) {
            source.sendMessage(Component.text("You do not have permission to use this command."));
            return;
        }

        if (args.length != 3) {
            source.sendMessage(Component.text("Usage: /litebansweb players add <player>"));
            return;
        }

        String playerName = args[2];

        executeCommand(source, playerName, true);
    }

    @Override
    protected void sendMessage(Object source, String message) {
        if (source instanceof CommandSource sender) {
            sender.sendMessage(Component.text(message));
        }
    }
}
