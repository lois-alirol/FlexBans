package fr.neocle.litebansweb.commands.Shared;

import fr.neocle.litebansweb.api.LitebansWebAPI;
import fr.neocle.litebansweb.api.whitelist.DiscordWhitelist;

import java.nio.file.Path;
import java.util.logging.Logger;

public abstract class DiscordWhitelistCommand {
    private final DiscordWhitelist whitelist;

    public DiscordWhitelistCommand(LitebansWebAPI api, Path configFile, Logger logger) {
        this.whitelist = api.getDiscordWhitelist();
    }

    /**
     * Executes the command for adding or removing a player.
     *
     * @param source The command sender
     * @param playerName The player to add/remove
     * @param isAdding true = add, false = remove
     */
    public void executeCommand(Object source, String playerName, boolean isAdding) {
        synchronized (this) {
            boolean success = isAdding ? whitelist.addUser(playerName) : whitelist.removeUser(playerName);

            if (success) {
                sendMessage(source, isAdding ? "Discord user added successfully." : "Discord user removed successfully.");
            } else {
                sendMessage(source, isAdding ? "Discord user is already whitelisted." : "Discord user is not in the whitelist.");
            }
        }
    }

    protected abstract void sendMessage(Object source, String message);
}
