package fr.neocle.litebansweb.commands.SubCommands.Bungee.PlayersWhitelistSubArgs;

import fr.neocle.litebansweb.api.LitebansWebAPI;
import fr.neocle.litebansweb.commands.Shared.PlayersWhitelistCommand;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.plugin.Command;

import java.nio.file.Path;
import java.util.logging.Logger;

public class RemovePlayer extends Command {
    private final PlayersWhitelistCommand whitelistMethods;

    public RemovePlayer(LitebansWebAPI api, Path dataFolder, Logger logger) {
        super("remove");
        this.whitelistMethods = new PlayersWhitelistCommand(api, dataFolder.resolve("config.yml"), logger) {
            @Override
            protected void sendMessage(Object sender, String message) {
                if (sender instanceof CommandSender commandSender) {
                    commandSender.sendMessage(new TextComponent(message));
                }
            }
        };
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!sender.hasPermission("litebansweb.players.remove")) {
            sender.sendMessage(new TextComponent("You do not have permission to use this command."));
            return;
        }

        if (args.length != 2) {
            sender.sendMessage(new TextComponent("Usage: /litebansweb players remove <player>"));
            return;
        }

        String playerName = args[1];

        whitelistMethods.executeCommand(sender, playerName, false);
    }
}
