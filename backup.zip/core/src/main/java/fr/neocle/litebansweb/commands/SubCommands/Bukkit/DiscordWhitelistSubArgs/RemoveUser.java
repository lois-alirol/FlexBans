package fr.neocle.litebansweb.commands.SubCommands.Bukkit.DiscordWhitelistSubArgs;

import fr.neocle.litebansweb.api.LitebansWebAPI;
import fr.neocle.litebansweb.commands.Shared.DiscordWhitelistCommand;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

import java.nio.file.Path;
import java.util.logging.Logger;

public class RemoveUser implements CommandExecutor {
    private final DiscordWhitelistCommand whitelistMethods;

    public RemoveUser(LitebansWebAPI api, Path dataFolder, Logger logger) {
        this.whitelistMethods = new DiscordWhitelistCommand(api, dataFolder.resolve("config.yml"), logger) {
            @Override
            protected void sendMessage(Object sender, String message) {
                if (sender instanceof CommandSender commandSender) {
                    commandSender.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
                }
            }
        };
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("litebansweb.discord.remove")) {
            sender.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
            return true;
        }

        if (args.length != 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /litebansweb discord remove <user>");
            return true;
        }

        String userId = args[1];
        whitelistMethods.executeCommand(sender, userId, false);
        return true;
    }
}
