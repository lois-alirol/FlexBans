package fr.neocle.litebansweb.commands.SubCommands.Bungee.DiscordWhitelistSubArgs;

import fr.neocle.litebansweb.api.LitebansWebAPI;
import fr.neocle.litebansweb.commands.Shared.DiscordWhitelistCommand;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.plugin.Command;

import java.nio.file.Path;
import java.util.logging.Logger;

public class AddUser extends Command {
    private final DiscordWhitelistCommand whitelistMethods;

    public AddUser(LitebansWebAPI api, Path dataFolder, Logger logger) {
        super("add");
        this.whitelistMethods = new DiscordWhitelistCommand(api, dataFolder.resolve("config.yml"), logger) {
            @Override
            protected void sendMessage(Object sender, String message) {
                if (sender instanceof CommandSender commandSender) {
                    commandSender.sendMessage(new TextComponent(message));
                }
            }
        };
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        if (!sender.hasPermission("litebansweb.discord.add")) {
            sender.sendMessage(new TextComponent("You do not have permission to use this command."));
            return;
        }

        if (args.length != 2) {
            sender.sendMessage(new TextComponent("Usage: /litebansweb discord add <user>"));
            return;
        }

        String userId = args[1];

        whitelistMethods.executeCommand(sender, userId, true);
    }
}
